package com.usbcheckerfrp

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

// ---------------- URL MANAGER ----------------

fun normalizeUrl(s: String): String {
    val t = s.trim()
    return if (t.isEmpty() || t.contains("://")) t else "https://$t"
}

fun validUrl(s: String): Boolean = try {
    val u = java.net.URI(s)
    (u.scheme == "http" || u.scheme == "https") && !u.host.isNullOrBlank()
} catch (e: Exception) {
    false
}

fun makeQr(text: String, size: Int = 640): Bitmap? = try {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
    Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
} catch (e: Exception) {
    null
}

@Composable
fun UrlScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val clip = LocalClipboardManager.current
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var urls by remember { mutableStateOf(store.urls()) }
    var confirmOpen by remember { mutableStateOf(false) }
    val url = normalizeUrl(input)
    val ok = validUrl(url)

    Page("URL Manager / ইউআরএল ম্যানেজার", onBack) {
        Panel {
            OutlinedTextField(
                value = input, onValueChange = { input = it; msg = ""; qr = null },
                label = { Text("Enter or paste URL / ইউআরএল লিখুন") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                isError = input.isNotBlank() && !ok
            )
            Text(
                when {
                    input.isBlank() -> "Waiting for URL"
                    ok -> "Valid URL ✓ → $url"
                    else -> "Invalid URL format (use http:// or https://)"
                },
                color = if (ok) Green else Muted, fontSize = 13.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                    input = clip.getText()?.text ?: ""
                }) { Text("Paste") }
                OutlinedButton(modifier = Modifier.weight(1f), enabled = ok, onClick = {
                    clip.setText(AnnotatedString(url)); msg = "Copied / কপি হয়েছে"
                }) { Text("Copy") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(modifier = Modifier.weight(1f), enabled = ok, onClick = {
                    store.addUrl(url); urls = store.urls(); msg = "Saved / সংরক্ষিত"
                }) { Text("Save") }
                OutlinedButton(modifier = Modifier.weight(1f), enabled = ok, onClick = {
                    qr = makeQr(url)
                    if (qr == null) msg = "QR could not be generated (text too long?)"
                }) { Text("QR Code") }
            }
            Button(
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = ok, onClick = { confirmOpen = true }
            ) { Text("Open URL / ইউআরএল খুলুন", fontWeight = FontWeight.Bold) }
            if (msg.isNotEmpty()) Text(msg, color = Cyan)
        }

        qr?.let { Panel { Image(it.asImageBitmap(), "QR code", Modifier.fillMaxWidth().height(260.dp)) } }

        Panel {
            Text("Saved URLs / সংরক্ষিত ইউআরএল", fontWeight = FontWeight.Bold)
            if (urls.isEmpty()) Text("None yet / এখনো নেই", color = Muted)
            urls.forEach { u ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(u, fontSize = 13.sp, modifier = Modifier.weight(1f).clickable { input = u; msg = "" })
                    TextButton(onClick = { store.removeUrl(u); urls = store.urls() }) { Text("Delete", color = Red) }
                }
            }
        }
    }

    if (confirmOpen) {
        AlertDialog(
            onDismissRequest = { confirmOpen = false },
            title = { Text("Open URL?") },
            text = { Text("$url\n\nOnly open links on a device you own or are authorized to use.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmOpen = false
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        store.addUrl(url); urls = store.urls()
                    } catch (e: ActivityNotFoundException) {
                        msg = "No browser available to open this link."
                    }
                }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { confirmOpen = false }) { Text("Cancel") } }
        )
    }
}

// ---------------- APK TRANSFER ----------------

data class ApkData(
    val file: File, val name: String, val size: Long, val sha: String, val zipOk: Boolean,
    val pkg: String?, val label: String?, val vName: String?, val vCode: Long,
    val minSdk: Int, val targetSdk: Int, val signed: Boolean, val abiOk: Boolean, val abis: String
)

@Suppress("DEPRECATION")
fun inspectApk(ctx: Context, uri: Uri): ApkData {
    val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
    val f = File(dir, "selected.apk")
    var name = "selected.apk"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
    }
    val md = MessageDigest.getInstance("SHA-256")
    val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open file")
    input.use { ins ->
        FileOutputStream(f).use { out ->
            val buf = ByteArray(65536)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                out.write(buf, 0, n)
            }
        }
    }
    val sha = md.digest().joinToString("") { "%02x".format(it) }

    var zipOk = false
    val abiSet = HashSet<String>()
    try {
        ZipFile(f).use { z ->
            zipOk = z.getEntry("AndroidManifest.xml") != null
            val en = z.entries()
            while (en.hasMoreElements()) {
                val n = en.nextElement().name
                if (n.startsWith("lib/")) n.split("/").getOrNull(1)?.let { abiSet.add(it) }
            }
        }
    } catch (e: Exception) {
        zipOk = false
    }
    val abiOk = abiSet.isEmpty() || abiSet.any { it in Build.SUPPORTED_ABIS }

    val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
    val pm = ctx.packageManager
    val pi = try { pm.getPackageArchiveInfo(f.absolutePath, flags) } catch (e: Exception) { null }
    var label: String? = null
    var minSdk = 0
    var target = 0
    pi?.applicationInfo?.let {
        it.sourceDir = f.absolutePath
        it.publicSourceDir = f.absolutePath
        label = try { it.loadLabel(pm).toString() } catch (e: Exception) { null }
        minSdk = it.minSdkVersion
        target = it.targetSdkVersion
    }
    val vCode = if (pi == null) 0L else if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    val signed = if (pi == null) false else if (Build.VERSION.SDK_INT >= 28)
        pi.signingInfo?.apkContentsSigners?.isNotEmpty() == true else pi.signatures?.isNotEmpty() == true
    return ApkData(f, name, f.length(), sha, zipOk, pi?.packageName, label, pi?.versionName, vCode, minSdk, target, signed, abiOk, abiSet.joinToString(", "))
}

@Suppress("DEPRECATION")
fun installedVersion(ctx: Context, pkg: String): Long? = try {
    val p = ctx.packageManager.getPackageInfo(pkg, 0)
    if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
} catch (e: Exception) {
    null
}

fun canInstall(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 26) ctx.packageManager.canRequestPackageInstalls() else true

@Composable
fun ApkScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var apk by remember { mutableStateOf<ApkData?>(null) }
    var msg by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var allowed by remember { mutableStateOf(canInstall(ctx)) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = "Reading APK… / পড়া হচ্ছে…"
            try {
                val d = withContext(Dispatchers.IO) { inspectApk(ctx, uri) }
                apk = d; status = ""; msg = ""
                store.addHistory("APK selected: ${d.name} pkg=${d.pkg} sha256=${d.sha.take(16)}…")
            } catch (e: Exception) {
                apk = null; msg = "Could not read the file: ${e.message}"
            }
        }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")) { uri ->
        val a = apk
        if (uri != null && a != null) scope.launch {
            msg = try {
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)?.use { o -> a.file.inputStream().use { it.copyTo(o) } }
                }
                store.addHistory("APK copied to chosen location: ${a.name}")
                "Copied ✓ (choose a USB storage in the picker to transfer to USB) / কপি হয়েছে"
            } catch (e: Exception) {
                "Copy failed: ${e.message}"
            }
        }
    }

    Page("APK Transfer / এপিকে ট্রান্সফার", onBack) {
        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            pick.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream"))
        }) { Text("Select APK file / এপিকে নির্বাচন") }
        if (msg.isNotEmpty()) Text(msg, color = Cyan)

        val a = apk
        if (a == null) {
            Note("No APK selected. Installs are never silent; Android always asks for your approval.\nইনস্টল সবসময় আপনার অনুমতিতে হয়, নীরবে নয়।", Muted)
        } else {
            val compatible = a.minSdk <= Build.VERSION.SDK_INT
            val installed = a.pkg?.let { installedVersion(ctx, it) }
            Panel {
                Text("APK information", fontWeight = FontWeight.Bold)
                InfoRow("File", a.name)
                InfoRow("Size", "%.2f MB".format(a.size / 1048576.0))
                InfoRow("Package", a.pkg ?: "unreadable")
                InfoRow("App name", a.label ?: "-")
                InfoRow("Version", "${a.vName ?: "-"} (${a.vCode})")
                InfoRow("Min / Target SDK", "${a.minSdk} / ${a.targetSdk}")
                InfoRow("SHA-256", a.sha)
            }
            Panel {
                Text("Checks", fontWeight = FontWeight.Bold)
                InfoRow("Valid archive", yn(a.zipOk))
                InfoRow("Package readable", yn(a.pkg != null))
                InfoRow("Signed", yn(a.signed))
                InfoRow("Android compatible", yn(compatible) + " (this phone API ${Build.VERSION.SDK_INT})")
                InfoRow("CPU compatible", yn(a.abiOk) + if (a.abis.isNotEmpty()) " [${a.abis}]" else "")
                InfoRow("Installed now", if (installed == null) "No" else "Yes (code $installed)")
                InfoRow("Install permission", yn(allowed))
                Text("Integrity here means: valid archive + parsed manifest + signature present. Compare SHA-256 with the publisher's value for authenticity.", color = Muted, fontSize = 12.sp)
            }
            val ready = a.zipOk && a.pkg != null && compatible && a.abiOk
            if (!allowed) {
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Allow installs from this app / অনুমতি দিন") }
            }
            Button(modifier = Modifier.fillMaxWidth(), enabled = ready && allowed, onClick = {
                try {
                    val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", a.file)
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    store.addHistory("Install requested: ${a.pkg}")
                } catch (e: Exception) {
                    msg = "Cannot start installer: ${e.message}"
                }
            }) { Text("Install (you approve) / ইনস্টল") }
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                allowed = canInstall(ctx)
                val v = a.pkg?.let { installedVersion(ctx, it) }
                status = when {
                    v == null -> "Not installed"
                    v >= a.vCode -> "Installed (version code $v) ✓"
                    else -> "Older version installed (code $v)"
                }
                store.addHistory("Install status ${a.pkg}: $status")
            }) { Text("Check install status / স্ট্যাটাস দেখুন") }
            if (status.isNotEmpty()) Text(status, color = Green)
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { save.launch(a.name) }) {
                Text("Copy APK to storage / USB drive")
            }
        }
    }
}
