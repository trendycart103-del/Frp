package com.usbcheckerfrp

data class Step(val title: String, val detail: String)
data class Article(val title: String, val body: String)

/** Offline documentation. Only legitimate, owner-authorized recovery methods. */
object Guides {
    val frp = listOf(
        Step(
            "1. Confirm ownership / মালিকানা নিশ্চিত করুন",
            "Gather proof: purchase receipt, box with IMEI, warranty card.\nক্রয়ের রসিদ, বক্স (IMEI সহ) ও ওয়ারেন্টি কার্ড সংগ্রহ করুন।"
        ),
        Step(
            "2. Find the Google account / গুগল অ্যাকাউন্ট খুঁজুন",
            "FRP asks for the Google account that was last signed in on the phone. Check old emails, Play Store receipts and other devices.\nফোনে সর্বশেষ যে গুগল অ্যাকাউন্টে লগইন ছিল সেটিই লাগবে। পুরোনো ইমেইল ও অন্য ডিভাইস দেখুন।"
        ),
        Step(
            "3. Recover the password / পাসওয়ার্ড রিকভার করুন",
            "On another device open accounts.google.com/signin/recovery and follow Google's steps (recovery phone/email).\nঅন্য ডিভাইসে accounts.google.com/signin/recovery খুলে গুগলের ধাপ অনুসরণ করুন।"
        ),
        Step(
            "4. Wait after a password change / পাসওয়ার্ড বদলের পর অপেক্ষা",
            "After a password reset Google can restrict sign-in on the locked phone for roughly 24-72 hours. Wait, then retry.\nপাসওয়ার্ড রিসেটের পর ২৪-৭২ ঘণ্টা পর্যন্ত সীমাবদ্ধতা থাকতে পারে। অপেক্ষা করে আবার চেষ্টা করুন।"
        ),
        Step(
            "5. Sign in on the phone / ফোনে সাইন ইন করুন",
            "On the setup screen sign in with the recovered account using the on-screen keyboard.\nসেটআপ স্ক্রিনে রিকভার করা অ্যাকাউন্ট দিয়ে সাইন ইন করুন।"
        ),
        Step(
            "6. Second-hand phone / ব্যবহৃত ফোন",
            "Ask the previous owner to remove the account (Settings > Accounts) or to remove the device at myaccount.google.com > Security > Your devices.\nআগের মালিককে অ্যাকাউন্ট রিমুভ করতে বলুন।"
        ),
        Step(
            "7. Authorized service center / অনুমোদিত সার্ভিস সেন্টার",
            "If recovery is impossible, visit the manufacturer's authorized service center with proof of purchase. They can verify ownership and help.\nরিকভারি সম্ভব না হলে ক্রয়ের প্রমাণসহ প্রস্তুতকারকের অনুমোদিত সার্ভিস সেন্টারে যান।"
        )
    )

    val lock = listOf(
        Step(
            "1. Try remembered credentials / মনে থাকা পিন/প্যাটার্ন চেষ্টা করুন",
            "Try your usual PIN, pattern or password variants. Smart Lock (trusted place/device) may unlock if it was enabled.\nআপনার সম্ভাব্য পিন/প্যাটার্ন চেষ্টা করুন। স্মার্ট লক চালু থাকলে ব্যবহার করুন।"
        ),
        Step(
            "2. Manufacturer account service / প্রস্তুতকারকের সার্ভিস",
            "If you registered the phone, use the manufacturer's find/unlock service (for example Samsung Find My Mobile) from another device.\nফোন রেজিস্টার করা থাকলে অন্য ডিভাইস থেকে প্রস্তুতকারকের ফাইন্ড/আনলক সার্ভিস ব্যবহার করুন।"
        ),
        Step(
            "3. Google Find Hub / গুগল ফাইন্ড ডিভাইস",
            "android.com/find can erase the phone remotely if it is online and linked to your Google account. This DELETES all data.\nandroid.com/find দিয়ে রিমোট ইরেজ করা যায়, এতে সব ডাটা মুছে যাবে।"
        ),
        Step(
            "3a. DATA-LOSS WARNING / ডাটা হারানোর সতর্কতা",
            "A factory reset erases photos, messages and apps permanently. You cannot back up from a locked phone.\nফ্যাক্টরি রিসেটে ছবি, মেসেজ, অ্যাপ স্থায়ীভাবে মুছে যায়।"
        ),
        Step(
            "4. Factory reset via recovery mode / রিকভারি মোডে রিসেট",
            "Button combinations differ by model. Use the manufacturer's official support page for your exact model.\nবাটন কম্বিনেশন মডেলভেদে আলাদা। আপনার মডেলের অফিশিয়াল সাপোর্ট পেজ দেখুন।"
        ),
        Step(
            "5. After reset: FRP / রিসেটের পর FRP",
            "After a reset the phone asks for the last Google account (FRP). Follow the FRP Recovery Guide.\nরিসেটের পর শেষ গুগল অ্যাকাউন্ট চাইবে। FRP গাইড অনুসরণ করুন।"
        ),
        Step(
            "6. Verify device ownership / মালিকানা যাচাই",
            "Authorized service centers need proof of purchase and ID before helping with a locked phone.\nসার্ভিস সেন্টারে ক্রয়ের প্রমাণ ও পরিচয়পত্র লাগবে।"
        )
    )

    val docs = listOf(
        Article(
            "USB OTG basics / ইউএসবি ওটিজি",
            "OTG lets this phone act as USB host so it can talk to keyboards, mice, flash drives and other phones' accessory ports.\nNeeds: an OTG adapter or USB-C cable that supports data, and a phone with USB host support (shown on the dashboard).\nCharge-only cables will not work."
        ),
        Article(
            "HID mouse/keyboard limits / এইচআইডি সীমাবদ্ধতা",
            "Host mode: this phone can USE a connected USB keyboard or mouse (the HID test screen checks it).\nGadget mode: making this phone BE a keyboard/mouse for another device is not supported by ordinary Android phones. It needs kernel support (/dev/hidg0) and usually root.\nHID input cannot unlock a phone and cannot bypass FRP."
        ),
        Article(
            "What is FRP? / এফআরপি কী?",
            "Factory Reset Protection is Google's anti-theft feature. After a factory reset, the phone needs the Google account that was previously on it. It protects owners and cannot be legitimately bypassed; use account recovery or the manufacturer."
        ),
        Article(
            "USB troubleshooting / ইউএসবি সমস্যা সমাধান",
            "1. Use a data-capable cable and a different OTG adapter.\n2. Replug and tap 'Allow' when permission is asked.\n3. Check 'USB Host' on the dashboard.\n4. Try another port or device to separate hardware faults.\n5. Restart the phone.\n6. Some phones disable OTG in settings (look for 'OTG connection')."
        ),
        Article(
            "APK installation / এপিকে ইনস্টল",
            "Android always asks you to approve installs. Allow 'Install unknown apps' for this app once, pick the APK, review the checks, then approve on the system installer screen. Silent installs are not possible."
        ),
        Article(
            "Build the APK / এপিকে বানানো",
            "Android Studio: open the project folder, wait for Gradle sync, then Build > Build APK(s). Command line: ./gradlew assembleDebug. Output: app/build/outputs/apk/debug/app-debug.apk."
        )
    )
}
