package com.usbcheckerfrp

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun progressOf(store: Store, prefix: String, n: Int): Int =
    (0 until n).count { store.done("$prefix$it") }

@Composable
fun RecoveryScreen(onBack: () -> Unit, go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val frpDone = progressOf(store, "frp", Guides.frp.size)
    val lockDone = progressOf(store, "lock", Guides.lock.size)
    Page("Recovery Assistant / রিকভারি অ্যাসিস্ট্যান্ট", onBack) {
        Note(
            "Authorized recovery only. This app does not bypass Google ownership verification or anti-theft protection.\nশুধুমাত্র অনুমোদিত রিকভারি। এই অ্যাপ গুগল মালিকানা যাচাই বা অ্যান্টি-থেফট বাইপাস করে না।",
            Cyan
        )
        Panel {
            Text("Device identification / ডিভাইস শনাক্তকরণ", fontWeight = FontWeight.Bold)
            InfoRow("Manufacturer", Build.MANUFACTURER)
            InfoRow("Model", Build.MODEL)
            InfoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            InfoRow("Security patch", Build.VERSION.SECURITY_PATCH ?: "-")
        }
        Panel {
            Text("Progress / অগ্রগতি", fontWeight = FontWeight.Bold)
            Text("FRP guide: $frpDone / ${Guides.frp.size}")
            LinearProgressIndicator(progress = { frpDone / Guides.frp.size.toFloat() }, modifier = Modifier.fillMaxWidth())
            Text("Screen lock guide: $lockDone / ${Guides.lock.size}")
            LinearProgressIndicator(progress = { lockDone / Guides.lock.size.toFloat() }, modifier = Modifier.fillMaxWidth())
        }
        Button(modifier = Modifier.fillMaxWidth(), onClick = { go(Screen.FRP) }) { Text("FRP Recovery Guide / এফআরপি গাইড") }
        Button(modifier = Modifier.fillMaxWidth(), onClick = { go(Screen.LOCK) }) { Text("Screen Lock Recovery / স্ক্রিন লক গাইড") }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { go(Screen.DOCS) }) { Text("Offline Documentation / অফলাইন ডকুমেন্টেশন") }
        Panel {
            Text("Limitation / সীমাবদ্ধতা", fontWeight = FontWeight.Bold)
            Text(
                "If a security feature blocks an action, the guide explains why and points to the manufacturer or Google account recovery.",
                color = Muted, fontSize = 13.sp
            )
        }
    }
}

@Composable
fun GuideScreen(title: String, prefix: String, steps: List<Step>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val checks = remember {
        mutableStateListOf<Boolean>().apply { steps.indices.forEach { add(store.done("$prefix$it")) } }
    }
    val done = checks.count { it }
    Page(title, onBack) {
        Panel {
            Text("Progress: $done / ${steps.size}", fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { done / steps.size.toFloat() }, modifier = Modifier.fillMaxWidth())
        }
        steps.forEachIndexed { i, s ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checks[i], onCheckedChange = {
                        checks[i] = it
                        store.setDone("$prefix$i", it)
                    })
                    Text(s.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                }
                Text(s.detail, color = Muted, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun DocsScreen(onBack: () -> Unit) {
    var open by remember { mutableStateOf(-1) }
    Page("Offline Documentation / অফলাইন ডকুমেন্টেশন", onBack) {
        Guides.docs.forEachIndexed { i, a ->
            Panel {
                Text(
                    (if (open == i) "▼ " else "▶ ") + a.title,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth().clickable { open = if (open == i) -1 else i }
                )
                if (open == i) Text(a.body, color = Muted, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var items by remember { mutableStateOf(store.history()) }
    Page("Diagnostic History / ডায়াগনস্টিক হিস্টোরি", onBack) {
        if (items.isEmpty()) Note("No history yet. Run a USB diagnostic or save device info.\nএখনো কোনো হিস্টোরি নেই।", Muted)
        items.forEach { Panel { Text(it, fontSize = 13.sp) } }
        if (items.isNotEmpty()) {
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { store.clearHistory(); items = emptyList() }) {
                Text("Clear history / মুছুন")
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var msg by remember { mutableStateOf("") }
    Page("Settings / সেটিংস", onBack) {
        Panel {
            Text("USB Checker FRP 1.0", fontWeight = FontWeight.Bold)
            Text("Offline-first. All data stays on this phone. No account, no server.\nসব ডাটা এই ফোনেই থাকে।", color = Muted, fontSize = 13.sp)
        }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { store.clearHistory(); msg = "History cleared" }) { Text("Clear diagnostic history") }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { store.clearUrls(); msg = "URLs cleared" }) { Text("Clear saved URLs") }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { store.resetProgress(); msg = "Guide progress reset" }) { Text("Reset recovery progress") }
        if (msg.isNotEmpty()) Text(msg, color = Cyan)
        Panel {
            Text("Known limits / সীমাবদ্ধতা", fontWeight = FontWeight.Bold)
            Text(
                "• HID gadget mode (phone acting as keyboard) is unsupported on most phones.\n• HID cannot unlock phones or bypass FRP.\n• Installs always need your approval.\n• USB host support depends on the phone.",
                color = Muted, fontSize = 13.sp
            )
        }
    }
}
