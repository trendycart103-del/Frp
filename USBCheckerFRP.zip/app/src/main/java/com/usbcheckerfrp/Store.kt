package com.usbcheckerfrp

import android.content.Context
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Simple local storage (SharedPreferences). No cloud, no database. */
class Store(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("usbfrp", Context.MODE_PRIVATE)

    private fun list(key: String): List<String> = try {
        val a = JSONArray(p.getString(key, "[]"))
        List(a.length()) { a.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save(key: String, l: List<String>) {
        p.edit().putString(key, JSONArray(l).toString()).apply()
    }

    fun urls(): List<String> = list("urls")
    fun addUrl(u: String) = save("urls", (listOf(u) + urls().filter { it != u }).take(100))
    fun removeUrl(u: String) = save("urls", urls().filter { it != u })
    fun clearUrls() = save("urls", emptyList())

    fun history(): List<String> = list("history")
    fun addHistory(text: String) {
        val t = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        save("history", (listOf("$t\n$text") + history()).take(200))
    }
    fun clearHistory() = save("history", emptyList())

    fun done(key: String): Boolean = p.getBoolean("p_$key", false)
    fun setDone(key: String, v: Boolean) = p.edit().putBoolean("p_$key", v).apply()
    fun resetProgress() {
        val e = p.edit()
        p.all.keys.filter { it.startsWith("p_") }.forEach { e.remove(it) }
        e.apply()
    }
}
