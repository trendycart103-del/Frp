package com.usbcheckerfrp

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import java.io.File
import java.io.FileOutputStream

enum class UsbState(val en: String, val bn: String) {
    CONNECTED("Connected", "সংযুক্ত"),
    DISCONNECTED("Disconnected", "বিচ্ছিন্ন"),
    UNSUPPORTED("Unsupported", "সমর্থিত নয়"),
    PERMISSION("Permission Required", "অনুমতি প্রয়োজন"),
    ERROR("Connection Error", "সংযোগে ত্রুটি")
}

object UsbHelper {
    const val ACTION = "com.usbcheckerfrp.USB_PERMISSION"

    fun mgr(ctx: Context): UsbManager = ctx.getSystemService(Context.USB_SERVICE) as UsbManager

    fun hostSupported(ctx: Context): Boolean =
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    fun accessorySupported(ctx: Context): Boolean =
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_ACCESSORY)

    fun devices(ctx: Context): List<UsbDevice> = try {
        mgr(ctx).deviceList.values.toList()
    } catch (e: Exception) {
        emptyList()
    }

    fun className(c: Int): String = when (c) {
        UsbConstants.USB_CLASS_AUDIO -> "Audio"
        UsbConstants.USB_CLASS_COMM -> "Communications"
        UsbConstants.USB_CLASS_HID -> "HID"
        UsbConstants.USB_CLASS_PRINTER -> "Printer"
        UsbConstants.USB_CLASS_MASS_STORAGE -> "Mass Storage"
        UsbConstants.USB_CLASS_HUB -> "Hub"
        UsbConstants.USB_CLASS_VIDEO -> "Video"
        UsbConstants.USB_CLASS_WIRELESS_CONTROLLER -> "Wireless"
        UsbConstants.USB_CLASS_PER_INTERFACE -> "Per-interface"
        UsbConstants.USB_CLASS_VENDOR_SPEC -> "Vendor-specific"
        else -> "Class $c"
    }

    fun interfaces(d: UsbDevice): List<String> = (0 until d.interfaceCount).map {
        val i = d.getInterface(it)
        var s = "#${i.id} ${className(i.interfaceClass)}"
        if (i.interfaceClass == UsbConstants.USB_CLASS_HID) {
            s += when (i.interfaceProtocol) {
                1 -> " (Keyboard)"
                2 -> " (Mouse)"
                else -> " (other HID)"
            }
        }
        s
    }

    fun hex(v: Int) = "%04X".format(v)

    fun product(d: UsbDevice): String = try { d.productName ?: "-" } catch (e: Exception) { "-" }
    fun manufacturer(d: UsbDevice): String = try { d.manufacturerName ?: "-" } catch (e: Exception) { "-" }

    /** Real verification: permission + open the device + read its descriptors. */
    fun verify(ctx: Context, d: UsbDevice): Pair<UsbState, String> {
        val m = mgr(ctx)
        if (!m.hasPermission(d)) return UsbState.PERMISSION to "Permission not granted yet"
        return try {
            val c = m.openDevice(d)
            if (c == null) {
                UsbState.ERROR to "openDevice() returned null"
            } else {
                val raw = c.rawDescriptors
                c.close()
                if (raw == null || raw.size < 18) UsbState.ERROR to "Could not read descriptors"
                else UsbState.CONNECTED to "Descriptors read OK (${raw.size} bytes)"
            }
        } catch (e: Exception) {
            UsbState.ERROR to (e.message ?: "Unknown error")
        }
    }

    fun requestPermission(ctx: Context, d: UsbDevice) {
        try {
            val i = Intent(ACTION).setPackage(ctx.packageName)
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            mgr(ctx).requestPermission(d, PendingIntent.getBroadcast(ctx, 0, i, flags))
        } catch (e: Exception) {
            // ignored: state will show an error on refresh
        }
    }
}

/**
 * USB HID *gadget* (this phone acting as a keyboard) is not available on ordinary phones.
 * It only works if the kernel exposes /dev/hidg0 and the app may write to it (usually root).
 */
object HidTyper {
    private val node = File("/dev/hidg0")

    fun nodeExists() = node.exists()
    fun writable() = node.exists() && node.canWrite()
    fun configFs() = File("/config/usb_gadget").exists() || File("/sys/kernel/config/usb_gadget").exists()

    private fun code(c: Char): Pair<Int, Int>? {
        return when {
            c in 'a'..'z' -> 0 to (0x04 + (c - 'a'))
            c in 'A'..'Z' -> 2 to (0x04 + (c - 'A'))
            c in '1'..'9' -> 0 to (0x1E + (c - '1'))
            c == '0' -> 0 to 0x27
            else -> {
                val un = "\n -=[]\\;'`,./"
                val unCodes = intArrayOf(0x28, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38)
                val sh = "!@#$%^&*()_+{}|:\"~<>?"
                val shCodes = intArrayOf(
                    0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
                    0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38
                )
                val a = un.indexOf(c)
                val b = sh.indexOf(c)
                if (a >= 0) 0 to unCodes[a] else if (b >= 0) 2 to shCodes[b] else null
            }
        }
    }

    fun type(text: String): String {
        if (!node.exists()) return "Not available: /dev/hidg0 does not exist on this phone."
        if (!node.canWrite()) return "Not available: no write permission to /dev/hidg0 (root/system access needed)."
        return try {
            FileOutputStream(node).use { o ->
                for (c in text) {
                    val k = code(c) ?: return "Unsupported character: '$c'"
                    o.write(byteArrayOf(k.first.toByte(), 0, k.second.toByte(), 0, 0, 0, 0, 0))
                    o.write(ByteArray(8))
                    o.flush()
                }
            }
            "Sent ${text.length} characters to the HID gadget."
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }
}
