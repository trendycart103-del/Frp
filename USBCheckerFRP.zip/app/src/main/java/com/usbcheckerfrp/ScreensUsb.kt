package com.usbcheckerfrp

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.TextView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat

// ---------------- USB STATUS ----------------

@Composable
fun UsbScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    var report by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                tick++
            }
        }
        val f = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(UsbHelper.ACTION)
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(r) } catch (e: Exception) { } }
    }

    val host = UsbHelper.hostSupported(ctx)
    val results = remember(tick) { UsbHelper.devices(ctx).map { it to UsbHelper.verify(ctx, it) } }
    val overall = when {
        !host -> UsbState.UNSUPPORTED
        results.isEmpty() -> UsbState.DISCONNECTED
        results.any { it.second.first == UsbState.CONNECTED } -> UsbState.CONNECTED
        results.any { it.second.first == UsbState.PERMISSION } -> UsbState.PERMISSION
        else -> UsbState.ERROR
    }

    Page("USB Status / ইউএসবি স্ট্যাটাস", onBack) {
        Panel {
            StateChip(overall)
            InfoRow("USB host (OTG)", yn(host))
            InfoRow("USB accessory", yn(UsbHelper.accessorySupported(ctx)))
            InfoRow("Devices found", results.size.toString())
        }
        if (!host) Note("This phone does not report USB host (OTG) support. USB device tests are unavailable.\nএই ফোন ওটিজি সমর্থন করে না বলে জানাচ্ছে।", Red)
        if (host && results.isEmpty()) Note("No USB device detected. Connect a device with a data-capable cable/OTG adapter.\nকোনো ইউএসবি ডিভাইস পাওয়া যায়নি। ওটিজি অ্যাডাপ্টারে ডিভাইস লাগান।")

        results.forEach { (d, v) ->
            Panel {
                Text(d.deviceName, fontWeight = FontWeight.Bold)
                StateChip(v.first)
                Text(v.second, color = Muted)
                InfoRow("VID:PID", "${UsbHelper.hex(d.vendorId)}:${UsbHelper.hex(d.productId)}")
                InfoRow("Product", UsbHelper.product(d))
                InfoRow("Manufacturer", UsbHelper.manufacturer(d))
                InfoRow("Device class", UsbHelper.className(d.deviceClass))
                InfoRow("Interfaces", UsbHelper.interfaces(d).joinToString("\n").ifEmpty { "-" })
                if (v.first == UsbState.PERMISSION) {
                    Button(onClick = { UsbHelper.requestPermission(ctx, d) }) { Text("Request permission / অনুমতি নিন") }
                }
            }
        }

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                tick++
                report = buildString {
                    append("USB diagnostic: ${overall.en}\n")
                    append("Host support: ${host}\n")
                    results.forEach { (d, v) ->
                        append("${d.deviceName} ${UsbHelper.hex(d.vendorId)}:${UsbHelper.hex(d.productId)} -> ${v.first.en} (${v.second})\n")
                    }
                }.trim()
                store.addHistory(report)
            }
        ) { Text("Run Diagnostic & Save / ডায়াগনস্টিক চালান") }
        if (report.isNotEmpty()) Panel { Text(report, fontSize = 13.sp) }

        Panel {
            Text("Troubleshooting / সমস্যা সমাধান", fontWeight = FontWeight.Bold)
            Text(
                "• Use a data cable, not charge-only.\n• Replug and tap Allow when asked.\n• Try another OTG adapter/port.\n• Enable 'OTG connection' in phone settings if present.\n• Restart the phone.\n• ডাটা-ক্যাবল ব্যবহার করুন, আবার প্লাগ করে Allow চাপুন।",
                color = Muted
            )
        }
    }
}


// ---------------- DEVICE INFO ----------------

@Composable
fun DeviceScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val kg = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    val provisioned = try {
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.DEVICE_PROVISIONED, 0) == 1
    } catch (e: Exception) { false }
    val rows = listOf(
        "Manufacturer" to Build.MANUFACTURER,
        "Brand" to Build.BRAND,
        "Model" to Build.MODEL,
        "Device" to Build.DEVICE,
        "Android version" to Build.VERSION.RELEASE,
        "API level" to Build.VERSION.SDK_INT.toString(),
        "Security patch" to (Build.VERSION.SECURITY_PATCH ?: "-"),
        "Build ID" to Build.ID,
        "Supported ABIs" to Build.SUPPORTED_ABIS.joinToString(", "),
        "Setup completed" to yn(provisioned),
        "Screen lock set" to yn(kg.isDeviceSecure),
        "USB host (OTG)" to yn(UsbHelper.hostSupported(ctx)),
        "USB accessory" to yn(UsbHelper.accessorySupported(ctx))
    )
    var saved by remember { mutableStateOf(false) }
    Page("Device Information / ডিভাইস তথ্য", onBack) {
        Panel { rows.forEach { InfoRow(it.first, it.second) } }
        Button(onClick = {
            store.addHistory("Device info: " + rows.joinToString("; ") { "${it.first}=${it.second}" })
            saved = true
        }) { Text(if (saved) "Saved ✓" else "Save to history / হিস্টোরিতে সংরক্ষণ") }
    }
}

// ---------------- HID ----------------

private fun isMouse(d: InputDevice) = (d.sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
private fun isKeyboard(d: InputDevice) =
    d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
        (d.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD

@Composable
fun HidScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    val inputs = remember(tick) {
        InputDevice.getDeviceIds().mapNotNull { InputDevice.getDevice(it) }.filter { !it.isVirtual }
    }
    val usbHid = remember(tick) {
        UsbHelper.devices(ctx).filter { d -> UsbHelper.interfaces(d).any { it.startsWith("#") && it.contains("HID") } }
    }
    val mice = inputs.filter { isMouse(it) }
    val keyboards = inputs.filter { isKeyboard(it) }

    var typed by remember { mutableStateOf("") }
    var lastKey by remember { mutableStateOf("-") }
    var urlText by remember { mutableStateOf(store.urls().firstOrNull() ?: "") }
    var authorized by remember { mutableStateOf(false) }
    var typeResult by remember { mutableStateOf("") }

    Page("HID Mouse & Keyboard / মাউস ও কীবোর্ড", onBack) {
        Note("HID input cannot unlock a locked phone or bypass FRP. Mouse and keyboard are separate functions.\nএইচআইডি ইনপুট দিয়ে লক খোলা বা FRP বাইপাস করা যায় না।", Cyan)

        Panel {
            Text("Host mode: use USB mouse/keyboard on this phone", fontWeight = FontWeight.Bold)
            InfoRow("Mouse detected", yn(mice.isNotEmpty()))
            InfoRow("Keyboard detected", yn(keyboards.isNotEmpty()))
            InfoRow("USB HID interfaces", usbHid.size.toString())
            inputs.forEach { Text("• ${it.name}", color = Muted) }
            OutlinedButton(onClick = { tick++ }) { Text("Refresh / রিফ্রেশ") }
        }

        Panel {
            Text("Mouse test / মাউস টেস্ট", fontWeight = FontWeight.Bold)
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(150.dp),
                factory = { c ->
                    TextView(c).apply {
                        text = "Move, click or scroll a mouse here"
                        setTextColor(0xFFFFFFFF.toInt())
                        setBackgroundColor(0xFF1E293B.toInt())
                        gravity = Gravity.CENTER
                        setOnGenericMotionListener { v, e ->
                            (v as TextView).text = "Hover/scroll x=${e.x.toInt()} y=${e.y.toInt()}\nbuttons=${e.buttonState}"
                            true
                        }
                        setOnTouchListener { v, e ->
                            val tool = if (e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) "MOUSE" else "TOUCH"
                            (v as TextView).text = "$tool x=${e.x.toInt()} y=${e.y.toInt()}\nbuttons=${e.buttonState}"
                            true
                        }
                    }
                }
            )
        }

        Panel {
            Text("Keyboard test / কীবোর্ড টেস্ট", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = typed, onValueChange = { typed = it },
                label = { Text("Type here with a USB keyboard") },
                modifier = Modifier.fillMaxWidth().onPreviewKeyEvent { e ->
                    val k = e.nativeKeyEvent
                    lastKey = "${KeyEvent.keyCodeToString(k.keyCode)} (device ${k.deviceId})"
                    false
                }
            )
            InfoRow("Last key", lastKey)
        }

        Panel {
            Text("Gadget mode: this phone as keyboard/mouse", fontWeight = FontWeight.Bold)
            InfoRow("/dev/hidg0 present", yn(HidTyper.nodeExists()))
            InfoRow("Writable", yn(HidTyper.writable()))
            InfoRow("configfs gadget", yn(HidTyper.configFs()))
            if (!HidTyper.writable()) {
                Text(
                    "Not supported on this phone (normal for most Android phones). Host-mode tests above still work.\nএই ফোনে গ্যাজেট মোড সমর্থিত নয়।",
                    color = Amber
                )
            }
            OutlinedTextField(
                value = urlText, onValueChange = { urlText = it },
                label = { Text("URL to type") }, modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = authorized, onCheckedChange = { authorized = it })
                Text("I own the target device; it is unlocked and I am authorized.", fontSize = 13.sp)
            }
            Button(
                enabled = authorized && urlText.isNotBlank() && HidTyper.writable(),
                onClick = {
                    typeResult = HidTyper.type(urlText.trim())
                    store.addHistory("HID type URL: $typeResult")
                }
            ) { Text("Type URL via HID / ইউআরএল টাইপ") }
            if (typeResult.isNotEmpty()) Text(typeResult, color = Muted)
        }
    }
}
