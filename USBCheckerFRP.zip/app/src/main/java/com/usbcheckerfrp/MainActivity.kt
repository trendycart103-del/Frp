package com.usbcheckerfrp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)
val Bg = Color(0xFF0B1220)
val PanelC = Color(0xFF131E33)
val Muted = Color(0xFF94A3B8)
val Green = Color(0xFF34D399)
val Red = Color(0xFFF87171)
val Amber = Color(0xFFFBBF24)

enum class Screen { HOME, USB, DEVICE, HID, URL, RECOVERY, FRP, LOCK, APK, DOCS, HISTORY, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, onPrimary = Bg, secondary = Blue,
                    background = Bg, onBackground = Color.White,
                    surface = PanelC, onSurface = Color.White,
                    surfaceVariant = PanelC, onSurfaceVariant = Muted
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) { AppRoot() }
            }
        }
    }
}

@Composable
fun AppRoot() {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }
    val back = { screen = Screen.HOME }
    when (screen) {
        Screen.HOME -> Dashboard { screen = it }
        Screen.USB -> UsbScreen(back)
        Screen.DEVICE -> DeviceScreen(back)
        Screen.HID -> HidScreen(back)
        Screen.URL -> UrlScreen(back)
        Screen.RECOVERY -> RecoveryScreen(back) { screen = it }
        Screen.FRP -> GuideScreen("FRP Recovery Guide / এফআরপি রিকভারি গাইড", "frp", Guides.frp, back)
        Screen.LOCK -> GuideScreen("Screen Lock Recovery / স্ক্রিন লক রিকভারি", "lock", Guides.lock, back)
        Screen.APK -> ApkScreen(back)
        Screen.DOCS -> DocsScreen(back)
        Screen.HISTORY -> HistoryScreen(back)
        Screen.SETTINGS -> SettingsScreen(back)
    }
}

// ---------- Reusable components ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Page(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        containerColor = Bg,
        topBar = {
            TopAppBar(
                title = { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PanelC, titleContentColor = Color.White,
                    navigationIconContentColor = Cyan
                )
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PanelC),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun Chip(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.2f)) {
        Text(
            text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun StateChip(s: UsbState) {
    val c = when (s) {
        UsbState.CONNECTED -> Green
        UsbState.DISCONNECTED -> Muted
        UsbState.UNSUPPORTED -> Red
        UsbState.PERMISSION -> Amber
        UsbState.ERROR -> Red
    }
    Chip("${s.en} / ${s.bn}", c)
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 14.sp, modifier = Modifier.weight(0.42f))
        Text(value, fontSize = 14.sp, modifier = Modifier.weight(0.58f))
    }
}

@Composable
fun Note(text: String, color: Color = Amber) {
    Panel { Text(text, color = color, fontSize = 14.sp) }
}

fun yn(b: Boolean) = if (b) "Yes / হ্যাঁ" else "No / না"

// ---------- Dashboard ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Tile(icon: ImageVector, en: String, bn: String, mod: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = mod.height(112.dp),
        colors = CardDefaults.cardColors(containerColor = PanelC),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(icon, contentDescription = null, tint = Cyan)
            Column {
                Text(en, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(bn, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

private data class T(val icon: ImageVector, val en: String, val bn: String, val to: Screen)

@Composable
fun Dashboard(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val host = UsbHelper.hostSupported(ctx)
    val sections = listOf(
        "Mode 1 · USB HID Compatibility / ইউএসবি এইচআইডি" to listOf(
            T(Icons.Filled.Edit, "HID Mouse & Keyboard", "মাউস ও কীবোর্ড", Screen.HID),
            T(Icons.Filled.Share, "URL Manager", "ইউআরএল ম্যানেজার", Screen.URL)
        ),
        "Mode 2 · USB & Device Diagnostics / ডায়াগনস্টিক" to listOf(
            T(Icons.Filled.Search, "USB Connection Status", "ইউএসবি স্ট্যাটাস", Screen.USB),
            T(Icons.Filled.Info, "Device Information", "ডিভাইস তথ্য", Screen.DEVICE),
            T(Icons.Filled.Send, "APK Transfer Assistant", "এপিকে ট্রান্সফার", Screen.APK),
            T(Icons.Filled.List, "Diagnostic History", "ডায়াগনস্টিক হিস্টোরি", Screen.HISTORY)
        ),
        "Mode 3 · Recovery & Authorized Integration / রিকভারি" to listOf(
            T(Icons.Filled.Build, "Recovery Assistant", "রিকভারি অ্যাসিস্ট্যান্ট", Screen.RECOVERY),
            T(Icons.Filled.Lock, "FRP Recovery Guide", "এফআরপি গাইড", Screen.FRP),
            T(Icons.Filled.Phone, "Screen Lock Guide", "স্ক্রিন লক গাইড", Screen.LOCK),
            T(Icons.Filled.Menu, "Offline Documentation", "অফলাইন ডকুমেন্টেশন", Screen.DOCS)
        ),
        "App / অ্যাপ" to listOf(
            T(Icons.Filled.Settings, "Settings", "সেটিংস", Screen.SETTINGS)
        )
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("USB Checker FRP", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Cyan)
        Text(
            "USB diagnostics, authorized recovery guides, offline.\nইউএসবি ডায়াগনস্টিক ও অনুমোদিত রিকভারি গাইড, অফলাইনে।",
            color = Muted, fontSize = 13.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(if (host) "USB Host: Yes" else "USB Host: No", if (host) Green else Red)
            Chip("Offline ✓", Cyan)
        }
        sections.forEach { (title, tiles) ->
            Spacer(Modifier.height(4.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Blue)
            tiles.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { t -> Tile(t.icon, t.en, t.bn, Modifier.weight(1f)) { go(t.to) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
