# USB Checker FRP - Build

## GitHub Actions (no installation needed)
1. Unzip this file on your computer.
2. Create a new GitHub repository. Upload the CONTENTS of the unzipped folder (so that `settings.gradle.kts`, `app/` and `.github/` are at the repository root). Make sure the hidden `.github` folder is included.
3. Open the repository > Actions tab > "Build APK" runs automatically on every push (or press "Run workflow").
4. When it finishes, open the run and download the artifact `USB-Checker-FRP-debug-apk` (contains app-debug.apk).

## Android Studio
Open the folder, wait for Gradle sync, then Build > Build APK(s).

## Notes
- minSdk 24, targetSdk 34, JDK 17, Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24.
- Not compiled by the author yet: if the Actions run fails, copy the red error lines and send them for a fix.
