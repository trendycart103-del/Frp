package com.sky22333.frpandroid.core.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sky22333.frpandroid.core.frp.DEFAULT_THEME_SEED_COLOR
import com.sky22333.frpandroid.core.frp.LanguageMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class FrpSettings(
    val bootStartEnabled: Boolean = false,
    val networkReconnectEnabled: Boolean = true,
    val autoRetryEnabled: Boolean = false,
    val screenOffKeepAliveEnabled: Boolean = false,
    val logRetentionDays: Int = 7,
    val themeSeedColor: Int = DEFAULT_THEME_SEED_COLOR,
    val languageMode: LanguageMode = LanguageMode.System,
    val pendingStart: Boolean = false,
)

interface SettingsGateway {
    val settings: Flow<FrpSettings>

    suspend fun setBootStartEnabled(enabled: Boolean)
    suspend fun setNetworkReconnectEnabled(enabled: Boolean)
    suspend fun setAutoRetryEnabled(enabled: Boolean)
    suspend fun setScreenOffKeepAliveEnabled(enabled: Boolean)
    suspend fun setLogRetentionDays(days: Int)
    suspend fun setThemeSeedColor(color: Int)
    suspend fun setLanguageMode(mode: LanguageMode)
    suspend fun setPendingStart(pending: Boolean)
}

private val Context.frpSettingsStore by preferencesDataStore("frp_settings")

class SettingsStore(private val context: Context) : SettingsGateway {
    override val settings: Flow<FrpSettings> = context.frpSettingsStore.data.map { preferences ->
        FrpSettings(
            bootStartEnabled = preferences[Keys.bootStart] ?: false,
            networkReconnectEnabled = preferences[Keys.networkReconnect] ?: true,
            autoRetryEnabled = preferences[Keys.autoRetry] ?: false,
            screenOffKeepAliveEnabled = preferences[Keys.screenOffKeepAlive] ?: false,
            logRetentionDays = preferences[Keys.logRetentionDays] ?: 7,
            themeSeedColor = preferences[Keys.themeSeedColor] ?: DEFAULT_THEME_SEED_COLOR,
            languageMode = preferences.enumValue(Keys.languageMode, LanguageMode.System),
            pendingStart = preferences[Keys.pendingStart] ?: false,
        )
    }

    override suspend fun setBootStartEnabled(enabled: Boolean) = set(Keys.bootStart, enabled)
    override suspend fun setNetworkReconnectEnabled(enabled: Boolean) = set(Keys.networkReconnect, enabled)
    override suspend fun setAutoRetryEnabled(enabled: Boolean) = set(Keys.autoRetry, enabled)
    override suspend fun setScreenOffKeepAliveEnabled(enabled: Boolean) = set(Keys.screenOffKeepAlive, enabled)
    override suspend fun setLogRetentionDays(days: Int) = set(Keys.logRetentionDays, days.coerceIn(1, 365))
    override suspend fun setThemeSeedColor(color: Int) = set(Keys.themeSeedColor, color)
    override suspend fun setLanguageMode(mode: LanguageMode) = set(Keys.languageMode, mode.name)
    override suspend fun setPendingStart(pending: Boolean) = set(Keys.pendingStart, pending)

    private suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        context.frpSettingsStore.edit { it[key] = value }
    }

    private fun <T : Enum<T>> Preferences.enumValue(key: Preferences.Key<String>, defaultValue: T): T {
        val value = this[key] ?: return defaultValue
        return runCatching {
            java.lang.Enum.valueOf(defaultValue.declaringJavaClass, value)
        }.getOrDefault(defaultValue)
    }

    private object Keys {
        val bootStart = booleanPreferencesKey("boot_start")
        val networkReconnect = booleanPreferencesKey("network_reconnect")
        val autoRetry = booleanPreferencesKey("auto_retry")
        val screenOffKeepAlive = booleanPreferencesKey("screen_off_keep_alive")
        val logRetentionDays = intPreferencesKey("log_retention_days")
        val themeSeedColor = intPreferencesKey("theme_seed_color")
        val languageMode = stringPreferencesKey("language_mode")
        val pendingStart = booleanPreferencesKey("pending_start")
    }
}
